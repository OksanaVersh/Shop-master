import ChangeCommodityDetail from './ChangeCommodityDetail';

export default ChangeCommodityDetail;
