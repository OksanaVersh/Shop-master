import CommodityPreviewCard from './CommodityPreviewCard';

export default CommodityPreviewCard;
