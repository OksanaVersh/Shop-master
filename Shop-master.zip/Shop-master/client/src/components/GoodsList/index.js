import GoodsList from './GoodsList';

export default GoodsList;
