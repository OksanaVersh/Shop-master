import ImgUploader from './ImgUploader';

export default ImgUploader;
