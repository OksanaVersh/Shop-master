import InputWithPrompts from './InputWithPrompts';

export default InputWithPrompts;
