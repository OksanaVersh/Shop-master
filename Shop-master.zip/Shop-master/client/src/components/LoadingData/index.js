import LoadingData from './LoadingData';

export default LoadingData;
