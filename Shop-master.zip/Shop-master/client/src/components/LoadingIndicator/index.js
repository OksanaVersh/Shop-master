import LoadingIndicator from './LoadingIndicator';

export default LoadingIndicator;
