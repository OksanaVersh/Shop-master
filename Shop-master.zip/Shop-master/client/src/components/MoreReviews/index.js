import MoreReviews from './MoreReviews';

export default MoreReviews;
