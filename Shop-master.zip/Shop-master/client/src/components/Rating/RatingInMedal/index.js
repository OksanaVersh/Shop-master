import RatingInMedal from './RatingInMedal';

export default RatingInMedal;
