import Rating from './Rating';

export default Rating;
