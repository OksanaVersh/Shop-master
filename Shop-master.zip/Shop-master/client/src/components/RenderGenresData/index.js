import RenderGenresData from './RenderGenresData';

export default RenderGenresData;
