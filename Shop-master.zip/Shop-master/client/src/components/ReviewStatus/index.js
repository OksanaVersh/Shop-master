import ReviewStatus from './ReviewStatus';

export default ReviewStatus;
