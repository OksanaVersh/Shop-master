import SwitchBuyBtn from './SwitchBuyBtn';

export default SwitchBuyBtn;
