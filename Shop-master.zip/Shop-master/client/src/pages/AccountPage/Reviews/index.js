import Reviews from './Reviews';

export default Reviews;
