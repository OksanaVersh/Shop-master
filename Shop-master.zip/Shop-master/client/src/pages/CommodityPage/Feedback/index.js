import Feedback from './Feedback';

export default Feedback;
