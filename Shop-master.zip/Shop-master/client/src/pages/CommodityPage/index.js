import CommodityPage from './CommodityPage';

export default CommodityPage;
