import CreateCommodityPage from './CreateСommodityPage';

export default CreateCommodityPage;
