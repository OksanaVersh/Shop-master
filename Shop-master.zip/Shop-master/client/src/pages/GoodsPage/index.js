import GoodsPage from './GoodsPage';

export default GoodsPage;
