import UpdateCommodityPage from './UpdateCommodityPage'

export default UpdateCommodityPage